//
//  ViewController.swift
//  Calculator
//
//  Created by Seth Penna on 6/26/16.
//  Copyright © 2016 Seth Penna. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
	
	
	// MARK: Properties
	
	var display: String = ""
	var initial: String = ""
	var second: String = ""
	var operatorType: Character = "p"
	var aData: String = ""
	var bData: String = ""
	var aState = false
	var bState = false
	
	@IBOutlet weak var displayText: UILabel!
	
	@IBOutlet weak var subDisplayView: UILabel!
	
	@IBOutlet weak var aLabel: UILabel!
	
	@IBOutlet weak var bLabel: UILabel!
	
	
	
	// MARK: Methods
	
	func updateDisplay(){
		if(display == ""){displayText.text = "0.0";}
		else{
			displayText.text = display
		}
	}
	
	override func viewDidLoad() {
		super.viewDidLoad()
		subDisplayView.text = ""
		aLabel.text = "A"
		bLabel.text = "B"
		updateDisplay()
		// Do any additional setup after loading the view, typically from a nib.
	}

	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}

	// MARK: Numbers
	
	@IBAction func number9(sender: UIButton) {
		display = display + "9"
		updateDisplay()
	}
	@IBAction func number8(sender: UIButton) {
		display = display + "8"
		updateDisplay()
	}
	@IBAction func number7(sender: UIButton) {
		display = display + "7"
		updateDisplay()
	}
	@IBAction func number6(sender: UIButton) {
		display = display + "6"
		updateDisplay()
	}
	@IBAction func number5(sender: UIButton) {
		display = display + "5"
		updateDisplay()
	}
	@IBAction func number4(sender: UIButton) {
		display = display + "4"
		updateDisplay()
	}
	@IBAction func number3(sender: UIButton) {
		display = display + "3"
		updateDisplay()
	}
	@IBAction func number2(sender: UIButton) {
		display = display + "2"
		updateDisplay()
	}
	@IBAction func number1(sender: UIButton) {
		display = display + "1"
		updateDisplay()
	}
	@IBAction func number0(sender: UIButton) {
		display = display + "0"
		updateDisplay()
	}
	@IBAction func decimal(sender: UIButton) {
		display = display + "."
		updateDisplay()
	}
	
	
	// MARK: Operators
	
	@IBAction func divide(sender: UIButton) {
		initial = display
		updateDisplay()
		display = ""
		subDisplayView.text = "/"
		operatorType = "d"
	}
	@IBAction func multiply(sender: UIButton) {
		initial = display
		updateDisplay()
		display = ""
		subDisplayView.text = "x"
		operatorType = "m"
	}
	@IBAction func subtract(sender: UIButton) {
		initial = display
		updateDisplay()
		display = ""
		subDisplayView.text = "-"
		operatorType = "s"
	}
	@IBAction func add(sender: UIButton) {
		initial = display
		updateDisplay()
		display = ""
		subDisplayView.text = "+"
		operatorType = "a"
	}
	
	@IBAction func equals(sender: UIButton) {
		subDisplayView.text = ""
		second = display
		switch operatorType {
		case "d":
			display = String(Double(initial)! / Double(second)!)
		case "m":
			display = String(Double(initial)! * Double(second)!)
		case "s":
			display = String(Double(initial)! - Double(second)!)
		case "a":
			display = String(Double(initial)! + Double(second)!)
		default:
			displayText.text = "Error"
		}
		
		updateDisplay()
	}
	
	
	@IBAction func clear(sender: UIButton) {
		subDisplayView.text = ""
		display = ""
		updateDisplay()
	}
	@IBAction func longPress(sender: UILongPressGestureRecognizer) {
		subDisplayView.text = ""
		aData = ""
		bData = ""
		aLabel.text = "A"
		bLabel.text = "B"
		aState = false
		bState = false
		display = ""
		updateDisplay()
	}
	@IBAction func sign(sender: UIButton) {
		display = "-" + display
		updateDisplay()
	}

	@IBAction func aButton(sender: UIButton) {
		// if the value hasn't been stored yet
		if(aState == false){
			aData = display
			display = ""
			updateDisplay()
			aLabel.text = "A: " + aData
			aState = true
		}
		
		// if the value has been set already
		else{
			display = aData
			aData = "A"
			aLabel.text = "A"
			updateDisplay()
			aState = false
		}
	}
	@IBAction func bButton(sender: UIButton) {
		// if the value hasn't been stored yet
		if(bState == false){
			bData = display
			display = ""
			updateDisplay()
			bLabel.text = "B: " + bData
			bState = true
		}
		
		// if the value has been set already
		else{
			display = bData
			bData = "B"
			bLabel.text = "B"
			updateDisplay()
			bState = false
		}
	}
	
}

